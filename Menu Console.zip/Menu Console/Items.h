void ItemsMenu()
{
	MenuFunctions.Name[1] = (char*)"TESTE1";
	MenuFunctions.Name[2] = (char*)"TESTE2";
	MenuFunctions.Name[3] = (char*)"HACK1";
	MenuFunctions.Name[4] = (char*)"HACK2";
	MenuFunctions.Name[5] = (char*)"PAPAPA1";
	MenuFunctions.Name[6] = (char*)"PAPAPA2";
	MenuFunctions.Name[7] = (char*)"CCASCASsdfsdfg";
	MenuFunctions.Items = 7;
}