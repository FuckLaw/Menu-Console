class Menu
{
public:
	int Index = 1;
	int Items = 7;
	char* Name[200];
	bool Variable[200];
};

Menu MenuFunctions = Menu();